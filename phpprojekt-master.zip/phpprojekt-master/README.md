# bildxzug-ART
bildxzug internes ArbeitsRapportTool
